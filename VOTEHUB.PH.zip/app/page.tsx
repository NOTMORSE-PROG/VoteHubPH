"use client"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Users,
  Vote,
  MessageSquare,
  MapPin,
  Shield,
  ArrowRight,
  Zap,
  TrendingUp,
  LogIn,
  UserPlus,
  Settings,
} from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-background">
      <nav className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
                <Vote className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="font-bold text-lg">VoteHubPH</span>
            </Link>
            <div className="flex items-center gap-3">
              <Link href="/settings">
                <Button variant="ghost" size="icon" className="rounded-lg">
                  <Settings className="h-5 w-5" />
                </Button>
              </Link>
              <Link href="/login">
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <LogIn className="h-4 w-4" />
                  Sign In
                </Button>
              </Link>
              <Link href="/register">
                <Button size="sm" className="gap-2">
                  <UserPlus className="h-4 w-4" />
                  Sign Up
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-16">
        {/* Hero Section */}
        <div className="max-w-5xl mx-auto mb-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-block mb-4 px-3 py-1 bg-primary/10 rounded-full">
                <span className="text-sm font-medium text-primary">🇵🇭 Philippine Elections</span>
              </div>
              <h2 className="text-5xl lg:text-6xl font-bold mb-6 text-balance leading-tight">
                Your Voice Shapes the Future
              </h2>
              <p className="text-xl text-muted-foreground mb-8 text-pretty leading-relaxed">
                Make informed voting decisions with transparent candidate information, community insights, and real-time
                engagement across all levels of Philippine government.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/browse">
                  <Button size="lg" className="w-full sm:w-auto">
                    Explore Candidates
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
            <div className="hidden lg:block">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-primary/5 rounded-2xl blur-3xl"></div>
                <div className="relative bg-gradient-to-br from-primary/10 to-primary/5 rounded-2xl p-8 border border-primary/20">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-4 bg-background rounded-lg border">
                      <Vote className="h-5 w-5 text-primary" />
                      <div className="text-sm">
                        <p className="font-medium">1000+ Candidates</p>
                        <p className="text-xs text-muted-foreground">Across all levels</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-4 bg-background rounded-lg border">
                      <MapPin className="h-5 w-5 text-primary" />
                      <div className="text-sm">
                        <p className="font-medium">17 Regions</p>
                        <p className="text-xs text-muted-foreground">Full coverage</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-4 bg-background rounded-lg border">
                      <Users className="h-5 w-5 text-primary" />
                      <div className="text-sm">
                        <p className="font-medium">Community Driven</p>
                        <p className="text-xs text-muted-foreground">Real discussions</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold mb-4">Why Choose VoteHubPH?</h3>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Everything you need to make informed voting decisions
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="border-primary/10 hover:border-primary/30 transition-colors">
              <CardHeader>
                <MapPin className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Location-Based Discovery</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Find candidates specific to your barangay, city, and region. Browse all 17 regions and 100+ cities
                  across the Philippines.
                </p>
              </CardContent>
            </Card>

            <Card className="border-primary/10 hover:border-primary/30 transition-colors">
              <CardHeader>
                <Shield className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Transparent Information</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Access detailed platforms, past contributions, party affiliations, and verified information about
                  every candidate.
                </p>
              </CardContent>
            </Card>

            <Card className="border-primary/10 hover:border-primary/30 transition-colors">
              <CardHeader>
                <MessageSquare className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Community Engagement</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Engage in discussions, share insights, and participate in community voting on candidate platforms and
                  initiatives.
                </p>
              </CardContent>
            </Card>

            <Card className="border-primary/10 hover:border-primary/30 transition-colors">
              <CardHeader>
                <Zap className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Real-Time Updates</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Stay informed with live candidate information, community posts, and engagement metrics updated in
                  real-time.
                </p>
              </CardContent>
            </Card>

            <Card className="border-primary/10 hover:border-primary/30 transition-colors">
              <CardHeader>
                <TrendingUp className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Voting Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  See community sentiment through voting and polling features. Understand what matters to your
                  neighbors.
                </p>
              </CardContent>
            </Card>

            <Card className="border-primary/10 hover:border-primary/30 transition-colors">
              <CardHeader>
                <Users className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Secure & Private</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Vote and comment anonymously or publicly. Your privacy and security are our top priority.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Stats Section */}
        <div className="bg-gradient-to-r from-primary/5 to-primary/10 rounded-2xl p-12 mb-20 border border-primary/20">
          <h3 className="text-3xl font-bold text-center mb-12">Platform Coverage</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">17</div>
              <div className="text-sm text-muted-foreground">Regions</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">100+</div>
              <div className="text-sm text-muted-foreground">Cities & Municipalities</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">500+</div>
              <div className="text-sm text-muted-foreground">Barangays</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">1000+</div>
              <div className="text-sm text-muted-foreground">Candidates</div>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center mb-20">
          <h3 className="text-3xl font-bold mb-4">Ready to Make Your Voice Heard?</h3>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands of Filipinos making informed voting decisions. Start exploring candidates today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/browse">
              <Button size="lg">Browse Candidates</Button>
            </Link>
            <Button onClick={() => {}} variant="outline" size="lg">
              Continue as Guest
            </Button>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t bg-muted/30 py-12 mt-20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">VoteHubPH</h4>
              <p className="text-sm text-muted-foreground">
                Empowering informed voting decisions across the Philippines.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Platform</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/browse" className="hover:text-foreground">
                    Browse Candidates
                  </Link>
                </li>
                <li>
                  <Link href="/elections" className="hover:text-foreground">
                    Elections & Statistics
                  </Link>
                </li>
                <li>
                  <Link href="/partylist" className="hover:text-foreground">
                    Party-List
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Account</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/login" className="hover:text-foreground">
                    Sign In
                  </Link>
                </li>
                <li>
                  <Link href="/register" className="hover:text-foreground">
                    Create Account
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground">
                    Terms of Service
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t pt-8 text-center text-sm text-muted-foreground">
            <p>© 2025 VoteHubPH. Empowering informed voting decisions across the Philippines.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
