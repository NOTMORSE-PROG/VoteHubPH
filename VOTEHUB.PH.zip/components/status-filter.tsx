"use client"

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface StatusFilterProps {
  value: string
  onValueChange: (value: string) => void
}

export function StatusFilter({ value, onValueChange }: StatusFilterProps) {
  return (
    <div className="space-y-1.5">
      <label className="text-sm font-medium">Experience</label>
      <Select value={value} onValueChange={onValueChange}>
        <SelectTrigger>
          <SelectValue placeholder="All" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All</SelectItem>
          <SelectItem value="incumbent">Running Again</SelectItem>
          <SelectItem value="challenger">First Time</SelectItem>
        </SelectContent>
      </Select>
    </div>
  )
}
